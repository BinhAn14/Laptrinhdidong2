package com.example.bt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
