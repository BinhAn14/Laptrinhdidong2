package com.example.gki

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
